
package runningawaygame;
import java.util.ArrayList;  
import java.io.*;                   
import java.util.Scanner;


public class Place {
    public static ArrayList<NPC> people = new ArrayList<>();
    private String name;
    private String desc;
    
    
public Place(String name)throws IOException { this.name = name;
File Places = new File("Places.txt");
Scanner pScan = new Scanner(Places);
setDesc(pScan, this.name);
}

public String getName() {return name;} 
public String getDesc() {return desc;}



public void setDesc(Scanner pScan, String name) throws IOException{
String testString = String.format(pScan.nextLine());
while(!testString.equals(name)){testString = pScan.nextLine();}
while(!testString.equals("desc")){testString = pScan.nextLine();}
desc = Utility.fileReader(pScan.nextLine());
//System.out.println(desc);
}



}//END