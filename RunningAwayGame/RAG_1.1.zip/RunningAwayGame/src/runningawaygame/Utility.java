/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package runningawaygame;

import java.util.Scanner;



public class Utility {
    
public static String fileReader(String toRead){
         toRead = toRead.replace("%n", "\n");
         if (toRead.charAt(0) == '<'){
             String specialCom = toRead.substring(1, 5);
             toRead = toRead.substring(6);   
             specialCom(specialCom);
         }       
         return toRead;       
    }

public static Place findPlaceFromString(Place[] places, String[] sPlaces, String placeString){
    int index = 0;  
    while(!sPlaces[index].equals(placeString)){
        index++;}
    return places[index];
    
    
    }
       
public static NPC findNPCFromString(NPC[] folks, String[] sFolks, String placeString){
    int index = 0;
    try{
    while(!sFolks[index].equalsIgnoreCase(placeString)){
        index++;}
    return folks[index];}
    catch(Exception e){System.out.println("hmm, that isn't a person, you seem to be talking to yourself"); return folks[0]; }
    }

public static String gotoPoint(Scanner scan, String gotoString){
            
            String tempString = "";
            //System.out.println("entering gotoPoint while loop");
            while(!tempString.equals(gotoString)){
            tempString = scan.nextLine();  
            //System.out.println(tempString);
            if(tempString.equals("END")){return "END";}
        }
            return "continue";   
}

public static void specialCom(String comString){
    switch(comString){
        case"get ": 
    }
}



}//END
