
package runningawaygame;

/**
 *
 * @author natoast
 */
public class Player {
    private Place currentPlace;
    private int placeIndex;
    
    public Player(Place start){System.out.println("commands: goto [location], look, (list) places, talk [NPC], end") ;currentPlace = start;}
    
    public void setPlace(String choice, String[] sPlaces, Place[] places){      
        for (int i = 0; i < sPlaces.length; i++){
            if(choice.equals(sPlaces[i])){
                placeIndex = i;
                currentPlace = places[i];
                System.out.println("You are now at " + choice); return;}
        }
        System.out.println("invalid location");
    }
    
    public Place getPlace(){return currentPlace; }
    
    
    
    
    
    
}//END

