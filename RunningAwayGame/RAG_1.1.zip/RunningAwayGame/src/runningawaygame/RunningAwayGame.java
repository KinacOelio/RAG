
package runningawaygame;
import java.io.*;
import java.util.*;
/**
 *
 * @author natoast
 */
public class RunningAwayGame {

    public static void main(String[] args) throws IOException {
        System.out.printf("test\n");
        
        //INITILIZING LOCATIONS
        //TODO: CONVERT PLACES ARRAY TO AUTOMATICALLY GENERATE (via constructor)
        Place home = new Place("home");
        Place church = new Place("church");
        Place store = new Place("store");
        Place[] places = {home, church, store};
        //string version parallel array of places
        String[] sPlaces = new String[3];
        for(int i = 0; i < 3; i++){
        sPlaces[i] = places[i].getName();}
        
        //initializing NPC's
        //something something politics
        NPC[] folks = new NPC[100];
        String[] sFolks = new String[100];
        File people = new File("People.txt");
        Scanner peepScan = new Scanner(people);
        int folksN = 0;
        
        //THIS BLOCK IS A DISASTER, PLEASE DO NOT TRY TO UNDERSTAND IT
        String cnt = "cnt";
        while(!cnt.equals("END")){
        cnt = Utility.gotoPoint(peepScan, "NPC");
        if(!cnt.equals("END")){
        String NPCname = peepScan.nextLine();
            sFolks[folksN] = NPCname;
        String NPCplaceStr = peepScan.nextLine(); 
        Place NPCplace = Utility.findPlaceFromString(places, sPlaces, NPCplaceStr);
        folks[folksN] = new NPC(NPCname, NPCplace);
        folksN++;
        }}
        System.out.println(folksN);
        peepScan.close();
        //-----------
        
        //initializing player. This is probably a stupid way to do this but here we are 
        Player Player1 = new Player(home);
        
        //all this shit is the while loop that actually runs the game
        boolean end = false; int n1 = 1; int n2 = 1;
        Scanner keyboard = new Scanner(System.in);
       
        while(!end){String uInput = keyboard.next();{
      
        switch(uInput){
            case "end": end = true; break;      
            case "goto": case "go": comGoto(Player1, keyboard, sPlaces, places); break;
            case "look": comLook(Player1); break;
            case "places": comListPlaces(sPlaces); break;
            case "talk": comTalk(keyboard, folks, sFolks, Player1); break;
            default: System.out.println("Try something that isn't stupid how about");}
        }
        }
        

    
} 
//-------------------------------------------------     
//the list of command methods for the switch statement      
public static void comGoto(Player Player1, Scanner keyboard, String[] sPlaces, Place[] places){
    String uInput2 = keyboard.next();  
    Player1.setPlace(uInput2, sPlaces, places);}

public static void comLook(Player Player1){
    System.out.print(Player1.getPlace().getDesc());
    System.out.println();}

public static void comListPlaces(String sPlaces[]){
    int l = sPlaces.length;
    System.out.print("You have discovered: ");
    for(int i = 0; i<l; i++){System.out.print(sPlaces[i] + "; ");}
    System.out.println();}

public static void comTalk(Scanner keyboard, NPC[] folks, String[] sFolks, Player Player1){
String NPCtoTalk = keyboard.next().toUpperCase();
NPC person = Utility.findNPCFromString(folks, sFolks, NPCtoTalk);
if(person.getPlace()==Player1.getPlace()){
person.talk();}
else{System.out.println("That person is not here!");}
 

}
//END COMMANDS BLOCK
//------------------



} //END
